package seb.tasks;

import java.math.BigDecimal;

public class CurrencyRateChange {
	private String currency;
	private BigDecimal rateChange;
	
	CurrencyRateChange(String currency, BigDecimal rateChange) {
		this.currency = currency;
		this.rateChange = rateChange;
	}
	
	// Getters

	public String getCurrency() {
		return currency;
	}

	public BigDecimal getRateChange() {
		return rateChange;
	}		
}
