package seb.tasks;

import java.util.Comparator;

public class CurrencyRateChangeComparator implements Comparator<CurrencyRateChange> {

	@Override
	public int compare(CurrencyRateChange crch1, CurrencyRateChange crch2) {
		return crch1.getRateChange().compareTo(crch2.getRateChange());
	}
}
