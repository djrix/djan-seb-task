package seb.tasks;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.w3c.dom.Element;

public class CurrencyExchange {

	private static final String RESOURCE_URL = "http://www.lb.lt/webservices/ExchangeRates/ExchangeRates.asmx/getExchangeRatesByDate?Date=";

	public static void main(String[] args) {

		//String inputDate = "2012-01-02";
		String inputDate = args[0];

		Date selectedDate = new Date();
		Date previousDate = new Date();

		// Parse date
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		try {
			selectedDate = formatter.parse(inputDate);

		} catch (ParseException e) {
			e.printStackTrace();
		}

		// Calculate previous date
		Calendar cal = Calendar.getInstance();
		cal.setTime(selectedDate);
		cal.add(Calendar.DAY_OF_MONTH, -1);
		previousDate = cal.getTime();

		HashMap<String, Currency> currencyMap1 = readSourceData(RESOURCE_URL + formatter.format(selectedDate));
		HashMap<String, Currency> currencyMap2 = readSourceData(RESOURCE_URL + formatter.format(previousDate));

		// Get currency change list
		List<CurrencyRateChange> currencyRateChangeList = generateCurrencyRateChangeList(currencyMap1, currencyMap2);

		// Sort currency rate changes decreasing by absolute values
		Collections.sort(currencyRateChangeList, Collections.reverseOrder(new CurrencyRateAbsChangeComparator()));

		// Sort currency rate changes decreasing, positive changes go first
		// Collections.sort(currencyRateChangeList, Collections.reverseOrder(new

		// Print the answer
		for (CurrencyRateChange crch : currencyRateChangeList) {
			System.out.println(crch.getCurrency() + ": " + crch.getRateChange().setScale(11, RoundingMode.HALF_UP));
		}
	}

	private static HashMap<String, Currency> readSourceData(String url) {

		HashMap<String, Currency> currencyMap = new HashMap<>();

		// Read xml

		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = null;
		Document d = null;

		try {
			db = dbf.newDocumentBuilder();
			d = db.parse(new URL(url).openStream());
		} catch (ParserConfigurationException | SAXException | IOException ex) {
			ex.printStackTrace();
		}

		d.getDocumentElement().normalize();

		NodeList nl = d.getElementsByTagName("item");

		for (int temp = 0; temp < nl.getLength(); temp++) {

			Node n = nl.item(temp);

			if (n.getNodeType() == Node.ELEMENT_NODE) {

				Element e = (Element) n;

				SimpleDateFormat formatter = new SimpleDateFormat("yyyy.MM.dd");
				String dateInString = e.getElementsByTagName("date").item(0).getTextContent();

				Date date = new Date();

				try {
					date = formatter.parse(dateInString);

				} catch (ParseException ex) {
					ex.printStackTrace();
				}

				String currency = e.getElementsByTagName("currency").item(0).getTextContent();
				Integer quantity = Integer.parseInt(e.getElementsByTagName("quantity").item(0).getTextContent());
				BigDecimal rate = new BigDecimal(e.getElementsByTagName("rate").item(0).getTextContent());
				String unit = e.getElementsByTagName("rate").item(0).getTextContent();

				Currency c = new Currency(date, currency, quantity, rate, unit);
				currencyMap.put(c.getCurrency(), c);
			}
		}

		return currencyMap;
	}

	private static List<CurrencyRateChange> generateCurrencyRateChangeList(HashMap<String, Currency> currencyMap1,
			HashMap<String, Currency> currencyMap2) {

		List<CurrencyRateChange> rateChangeList = new ArrayList<>();

		for (String key : currencyMap1.keySet()) {
			BigDecimal selectedDayCurrencyRatePerUnit = currencyMap1.get(key).getRatePerUnit();
			BigDecimal previousDayCurrencyRatePerUnit = currencyMap2.get(key).getRatePerUnit();
			BigDecimal rateChange = selectedDayCurrencyRatePerUnit.subtract(previousDayCurrencyRatePerUnit);
			rateChangeList.add(new CurrencyRateChange(key, rateChange));
		}

		return rateChangeList;
	}
}
