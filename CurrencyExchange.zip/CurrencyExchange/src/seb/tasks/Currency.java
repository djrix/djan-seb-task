package seb.tasks;

import java.math.BigDecimal;
import java.util.Date;

public class Currency {
	private Date date;
	private String currency;
	private Integer quantity;
	private BigDecimal rate;
	private String unit;
	
	public Currency(Date date, String currency, Integer quantity, BigDecimal rate, String unit) {
		this.date = date;
		this.currency = currency;
		this.quantity = quantity;
		this.rate = rate;
		this.unit = unit;
	}
	
	public BigDecimal getRatePerUnit() {
		BigDecimal q = new BigDecimal(quantity);
		BigDecimal ratePerUnit = rate.divide(q);
		return ratePerUnit;
	}
	
	// Getters

	public Date getDate() {
		return date;
	}

	public String getCurrency() {
		return currency;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public BigDecimal getRate() {
		return rate;
	}

	public String getUnit() {
		return unit;
	}	
}
