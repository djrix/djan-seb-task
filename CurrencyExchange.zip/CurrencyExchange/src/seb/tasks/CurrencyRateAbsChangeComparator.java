package seb.tasks;

import java.math.BigDecimal;
import java.util.Comparator;

public class CurrencyRateAbsChangeComparator implements Comparator<CurrencyRateChange> {

	@Override
	public int compare(CurrencyRateChange crch1, CurrencyRateChange crch2) {
		BigDecimal v1 = crch1.getRateChange().abs();
		BigDecimal v2 = crch2.getRateChange().abs();		
		return v1.compareTo(v2); 
	}
}
